// Third partu module
const express= require("express");
const app = express();
const mongoose=require("mongoose");
const morgan = require("morgan");
const cors = require("cors")





//Mildware
app.use(cors());
app.use(morgan("common"));
app.use(express.json());




//router
const infoRouter=require("./router");
app.use("/info",infoRouter);



app.listen(5000,()=>{
    console.log("server started on 5000");
});


//Db connection
// mongoose.connect("mongodb://localhost/tutorial",
// {  useNewUrlParser: true, 
//     useUnifiedTopology: true, 
//     useCreateIndex: true, 
//     useFindAndModify: false },(err) =>{
//     if(err){
//         console.log("DB connected successfully");
//     }
// });


mongoose.connect("mongodb://localhost/tutorial",
{  useNewUrlParser: true, 

    useUnifiedTopology: true 
    
    }, err => {
    if(err) throw err;
    console.log('Connected to MongoDB!!!')
    });
     